<?php
require_once 'dbconnect.php';
require_once 'email_availibilty.php';
password_check();
?>