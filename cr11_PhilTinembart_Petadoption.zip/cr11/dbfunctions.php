<?php
require_once 'dbconnect.php';
require_once 'email_availibilty.php';
check_email_avalibility();

?>